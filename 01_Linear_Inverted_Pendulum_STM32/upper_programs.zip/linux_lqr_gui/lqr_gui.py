#!/usr/bin/env python3
"""Simple state-driven LQR, Tk curves, and asynchronous CSV recording."""
import argparse
import csv
import math
import queue
import struct
import threading
import time
from collections import deque
from datetime import datetime
from pathlib import Path

# Copied from the supplied STM32 LQR. State order: x, v, theta, omega.
K = (-21.5565, -33.1765, -67.7560, -12.6289)

ANGLE_LIMIT = 0.3491
STATE_TIMEOUT = 0.2
CSV_FIELDS = ("t_s", "cnt", "x_m", "v_m_s", "theta_rad", "omega_rad_s",
              "u_raw", "u_sent", "mode", "rx_interval_ms", "rx_to_write_ms",
              "skipped_states")


def control(state):
    raw = -sum(k * s for k, s in zip(K, state))
    if not -ANGLE_LIMIT < state[2] < ANGLE_LIMIT:
        return raw, 0.0, "angle_zero"
    return raw, raw, "lqr"  # Actuator saturation is handled by STM32.


def pack_u(u):
    body = b"\xaa\x55" + struct.pack("<f", u)
    return body + bytes((sum(body) & 255, 13))


class StateLines:
    def __init__(self):
        self.pending = bytearray()
        self.discard = False
        self.bad = 0
        self.rx_errors = 0

    def feed(self, data):
        states = []
        for byte in data:
            if byte != 10:
                if not self.discard:
                    self.pending.append(byte)
                    if len(self.pending) > 1024:
                        self.pending.clear()
                        self.discard = True
                        self.bad += 1
                continue
            raw = bytes(self.pending)
            self.pending.clear()
            if self.discard:
                self.discard = False
                continue
            text = raw.decode("ascii", errors="replace").strip()
            if text.startswith("666"):
                text = text[3:]
            if text.startswith("<back>:"):
                continue  # Echo does not drive the control loop.
            if text == "RX ERROR":
                self.rx_errors += 1
                continue
            try:
                if not text.startswith("<32>:"):
                    raise ValueError()
                parts = text[5:].split(",")
                if len(parts) != 5:
                    raise ValueError()
                cnt = int(parts[0])
                values = tuple(float(v) for v in parts[1:])
                if not all(math.isfinite(v) for v in values):
                    raise ValueError()
                states.append((cnt, values))
            except ValueError:
                self.bad += 1
        return states


class Recorder(threading.Thread):
    def __init__(self, folder):
        super().__init__(daemon=True)
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        self.path = folder / ("lqr_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".csv")
        self.file = self.path.open("x", newline="", encoding="utf-8-sig")
        self.writer = csv.DictWriter(self.file, fieldnames=CSV_FIELDS)
        self.writer.writeheader()
        self.rows = queue.Queue(maxsize=20000)
        self.done = threading.Event()
        self.error = ""
        self.dropped = 0

    def add(self, row):
        try:
            self.rows.put_nowait(row)
        except queue.Full:
            self.dropped += 1

    def run(self):
        last_flush = time.monotonic()
        try:
            while not self.done.is_set() or not self.rows.empty():
                try:
                    row = self.rows.get(timeout=0.1)
                    self.writer.writerow(row)
                except queue.Empty:
                    pass
                if time.monotonic() - last_flush >= 1:
                    self.file.flush()
                    last_flush = time.monotonic()
        except Exception as exc:
            self.error = str(exc)
        finally:
            self.file.close()


class DemoSerial:
    """Synthetic curves only, not a pendulum dynamics simulation."""
    def __init__(self):
        self.start = self.next = time.monotonic()
        self.cnt = 0

    @property
    def in_waiting(self):
        return 1

    def read(self, count):
        time.sleep(0.005)
        now = time.monotonic()
        if now < self.next:
            return b""
        self.next = now + 0.020
        t = now - self.start
        state = (0.01*math.sin(t), 0.01*math.cos(t),
                 0.015*math.sin(2*t), 0.03*math.cos(2*t))
        self.cnt += 1
        return ("<32>:{},{:.4f},{:.4f},{:.4f},{:.4f}\n".format(self.cnt, *state)).encode("ascii")

    def write(self, data):
        return len(data)

    def close(self):
        pass


class Controller(threading.Thread):
    def __init__(self, port_factory, recorder):
        super().__init__(daemon=True)
        self.factory, self.recorder = port_factory, recorder
        self.end = threading.Event()
        self.command_lock = threading.Lock()
        self.samples_lock = threading.Lock()
        self.enabled = False
        self.zero_requested = False
        self.connected = False
        self.status = "正在打开串口"
        self.samples = deque(maxlen=10000)
        self.latencies = deque(maxlen=500)
        self.received = 0
        self.skipped = 0
        self.parser = StateLines()
        self.origin = time.monotonic()
        self.last_rx = None
        self.last_u = None
        self.sent_any = False

    def enable(self):
        with self.command_lock:
            if self.connected and self.last_rx is not None and time.monotonic() - self.last_rx < STATE_TIMEOUT:
                self.enabled = True
                self.status = "LQR 运行中"
                return True
            self.status = "等待有效四状态数据后再开始"
            return False

    def stop_control(self):
        with self.command_lock:
            self.enabled = False
            self.zero_requested = True

    def send(self, port, u):
        frame = pack_u(u)
        self.sent_any = True
        if port.write(frame) != 8:
            raise OSError("指令未完整写入 8 字节")
        self.last_u = u

    def send_zero(self, port, mode):
        self.send(port, 0.0)
        self.recorder.add(dict(t_s=time.monotonic()-self.origin, mode=mode, u_sent=0.0))
        with self.samples_lock:
            self.samples.append((time.monotonic()-self.origin, (None,)*4, 0.0))

    def on_states(self, port, states, rx_time):
        # If the OS delivers several queued states, control only the latest one.
        self.received += len(states)
        self.skipped += len(states)-1
        for old_cnt, old_state in states[:-1]:
            old_row = dict(zip(CSV_FIELDS[:6], (rx_time-self.origin, old_cnt, *old_state)))
            old_row.update(mode="skipped_backlog", skipped_states=0)
            self.recorder.add(old_row)
        cnt, state = states[-1]
        dt = (rx_time-self.last_rx)*1000 if self.last_rx is not None else ""
        self.last_rx = rx_time
        raw, u, mode = control(state)
        latency = ""
        with self.command_lock:
            if self.enabled:
                self.send(port, u)
                latency = (time.monotonic()-rx_time)*1000
                self.status = "LQR 运行中" if mode == "lqr" else "超出稳摆角度范围，输出 0"
            else:
                mode, u = "monitor", ""
        row = dict(zip(CSV_FIELDS[:6], (rx_time-self.origin, cnt, *state)))
        row.update(u_raw=raw, u_sent=u, mode=mode, rx_interval_ms=dt,
                   rx_to_write_ms=latency, skipped_states=len(states)-1)
        self.recorder.add(row)
        with self.samples_lock:
            self.samples.append((rx_time-self.origin, state, self.last_u))
            if latency != "":
                self.latencies.append(latency)

    def run(self):
        port = None
        try:
            port = self.factory()
            self.connected = True
            self.status = "已连接，正在监视；点击开始 LQR"
            while not self.end.is_set():
                with self.command_lock:
                    if self.zero_requested:
                        self.send_zero(port, "stop")
                        self.zero_requested = False
                        self.status = "已提交 u=0，监视中"
                    if self.enabled and self.last_rx is not None and time.monotonic()-self.last_rx > STATE_TIMEOUT:
                        self.enabled = False
                        self.send_zero(port, "state_timeout")
                        self.status = "四状态中断超过 0.2 秒，已提交 u=0"
                data = port.read(min(max(port.in_waiting, 1), 4096))
                rx_time = time.monotonic()
                states = self.parser.feed(data)
                if states:
                    self.on_states(port, states, rx_time)
        except Exception as exc:
            self.status = "串口异常：{}".format(exc)
        finally:
            self.connected = False
            self.enabled = False
            if port is not None:
                if self.sent_any:
                    try:
                        self.send_zero(port, "exit")
                    except Exception:
                        self.status = "串口异常，归零未确认，请用急停"
                        print(self.status, flush=True)
                port.close()


class PlotWindow:
    LABELS = ("x / m", "v / (m/s)", "theta / rad", "omega / (rad/s)", "u / V (command)")
    COLORS = ("#38bdf8", "#34d399", "#fbbf24", "#c084fc", "#fb7185")

    def __init__(self, root, worker, recorder, demo=False, window=10):
        import tkinter as tk
        self.root, self.worker, self.recorder = root, worker, recorder
        self.window, self.closed = window, False
        root.title("LQR 四状态与控制输出" + (" — 演示，不连接硬件" if demo else ""))
        root.geometry("1000x820")
        root.minsize(760, 650)
        bar = tk.Frame(root)
        bar.pack(fill="x", padx=10, pady=8)
        tk.Button(bar, text="开始 LQR", command=worker.enable, width=14).pack(side="left")
        tk.Button(bar, text="停止 / u=0", command=worker.stop_control, width=14).pack(side="left", padx=8)
        tk.Label(bar, text="K = [-32.5197, -37.7236, -77.4635, -14.3220]   u 不限幅").pack(side="left")
        self.status = tk.StringVar()
        tk.Label(root, textvariable=self.status, anchor="w", justify="left").pack(fill="x", padx=10)
        self.canvas = tk.Canvas(root, bg="#0f172a", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=10, pady=8)
        tk.Label(root, text="CSV：{}".format(recorder.path), anchor="w").pack(fill="x", padx=10, pady=(0, 8))
        self.last_count = 0
        self.last_report = time.monotonic()
        self.hz = 0.0
        root.protocol("WM_DELETE_WINDOW", self.close)
        self.refresh()

    def refresh(self):
        if self.closed:
            return
        now = time.monotonic()
        if now-self.last_report >= 1:
            self.hz = (self.worker.received-self.last_count)/(now-self.last_report)
            self.last_count, self.last_report = self.worker.received, now
        with self.worker.samples_lock:
            samples = list(self.worker.samples)
            timings = sorted(self.worker.latencies)
        p95 = timings[math.ceil(len(timings)*0.95)-1] if timings else 0
        latest = samples[-1][2] if samples else None
        self.status.set("{}  | 接收 {:.1f} Hz | u={}\n主机读取至提交发送 P95 {:.2f} ms | 跳过积压 {} | RX ERROR {} | 日志丢行 {} {}".format(
            self.worker.status, self.hz, "—" if latest is None else "{:.3f}".format(latest),
            p95, self.worker.skipped, self.worker.parser.rx_errors, self.recorder.dropped, self.recorder.error))
        self.draw(samples, now-self.worker.origin)
        self.after_id = self.root.after(100, self.refresh)  # Independent of serial control.

    def draw(self, samples, now):
        c = self.canvas
        c.delete("all")
        width, height = max(c.winfo_width(), 760), max(c.winfo_height(), 500)
        left, right = 95, width-18
        start, end = max(0, now-self.window), max(self.window, now)
        visible = [s for s in samples if s[0] >= start]
        for panel, (label, color) in enumerate(zip(self.LABELS, self.COLORS)):
            top = panel*(height/5)+24
            bottom = (panel+1)*(height/5)-22
            points = [(t, state[panel] if panel < 4 else u) for t, state, u in visible]
            valid = [(t, v) for t, v in points if v is not None and math.isfinite(v)]
            vals = [v for _, v in valid]
            lo, hi = (min(vals), max(vals)) if vals else (-1, 1)
            margin = max((hi-lo)*0.15, 0.001 if panel < 4 else 0.1)
            lo, hi = lo-margin, hi+margin
            c.create_text(10, top-12, text=label, anchor="w", fill=color)
            if vals:
                c.create_text(right, top-12, text="{:.4f}".format(vals[-1]), anchor="e", fill=color)
            for fraction in (0, 0.5, 1):
                y = top+(bottom-top)*fraction
                c.create_line(left, y, right, y, fill="#26354d")
                c.create_text(left-8, y, text="{:.3f}".format(hi-(hi-lo)*fraction), anchor="e", fill="#94a3b8")
            for fraction in (0, 0.5, 1):
                x = left+(right-left)*fraction
                c.create_line(x, top, x, bottom, fill="#26354d")
                if panel == 4:
                    c.create_text(x, bottom+12, text="{:.1f}s".format(start+(end-start)*fraction), fill="#94a3b8")
            coords = []
            # Up to one display point per horizontal pixel; CSV is not decimated.
            step = max(1, len(valid)//max(1, int(right-left)))
            for t, v in valid[::step]:
                coords.extend((left+(t-start)/(end-start)*(right-left),
                               bottom-(v-lo)/(hi-lo)*(bottom-top)))
            if len(coords) >= 4:
                c.create_line(*coords, fill=color, width=1.7)

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.root.after_cancel(self.after_id)
        self.worker.end.set()
        self.worker.join(timeout=1)
        if self.worker.is_alive():
            print("控制线程尚未退出，请确认急停。", flush=True)
        self.recorder.done.set()
        self.recorder.join(timeout=2)
        print("已保存：{}".format(self.recorder.path), flush=True)
        self.root.destroy()


def main():
    parser = argparse.ArgumentParser(description="接收四状态 → LQR → 下发 u；五条实时曲线与 CSV")
    parser.add_argument("--port", default="/dev/ttyUSB0")
    parser.add_argument("--demo", action="store_true", help="演示曲线，不连接串口")
    parser.add_argument("--log-dir", default=str(Path(__file__).resolve().parent / "logs"))
    args = parser.parse_args()
    import tkinter as tk
    root = tk.Tk()
    recorder = Recorder(args.log_dir)
    if args.demo:
        factory = DemoSerial
    else:
        def factory():
            import serial
            port = serial.Serial(port=None, baudrate=2000000, timeout=0.005,
                                 write_timeout=0.05, exclusive=True)
            port.dtr = False
            port.rts = False
            port.port = args.port
            port.open()
            return port
    worker = Controller(factory, recorder)
    recorder.start()
    worker.start()
    app = PlotWindow(root, worker, recorder, args.demo)
    try:
        root.mainloop()
    except KeyboardInterrupt:
        app.close()
    finally:
        if not app.closed:
            app.close()


if __name__ == "__main__":
    main()
