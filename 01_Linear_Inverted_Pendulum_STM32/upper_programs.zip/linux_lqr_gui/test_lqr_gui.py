import csv
import math
import queue
import struct
import tempfile
import time
import unittest
from pathlib import Path

import lqr_gui as app


class MemoryLog:
    path = Path("test.csv")
    dropped = 0
    error = ""

    def __init__(self):
        self.rows = []

    def add(self, row):
        self.rows.append(row)


class FakePort:
    def __init__(self):
        self.incoming = queue.Queue()
        self.writes = []
        self.closed = False
        self.fail_write = False

    @property
    def in_waiting(self):
        return 1

    def read(self, size):
        try:
            return self.incoming.get(timeout=0.005)
        except queue.Empty:
            return b""

    def write(self, packet):
        if self.fail_write:
            raise OSError("simulated write failure")
        self.writes.append(bytes(packet))
        return len(packet)

    def close(self):
        self.closed = True


def wait_for(condition, timeout=1):
    end = time.monotonic()+timeout
    while time.monotonic() < end:
        if condition():
            return
        time.sleep(0.005)
    raise AssertionError("condition timed out")


class Tests(unittest.TestCase):
    def setUp(self):
        self.port, self.log = FakePort(), MemoryLog()
        self.worker = app.Controller(lambda: self.port, self.log)

    def test_control_sign_matches_supplied_firmware(self):
        raw, u, mode = app.control((0.01, -0.02, 0.03, -0.04))
        expected = 32.5197*0.01 - 37.7236*0.02 + 77.4635*0.03 - 14.3220*0.04
        self.assertAlmostEqual(raw, expected)
        self.assertAlmostEqual(u, expected)
        self.assertEqual(mode, "lqr")

    def test_unclipped_output_and_original_angle_gate(self):
        self.assertAlmostEqual(app.control((10, 0, 0, 0))[1], 325.197)
        self.assertAlmostEqual(app.control((-10, 0, 0, 0))[1], -325.197)
        for angle in [0.3491, -0.3491, 1.5]:
            self.assertEqual(app.control((0, 0, angle, 0))[1:], (0, "angle_zero"))

    def test_unclipped_command_reaches_wire(self):
        self.worker.enabled = True
        self.worker.on_states(self.port, [(1, (1, 0, 0, 0))], time.monotonic())
        sent = struct.unpack('<f', self.port.writes[0][2:6])[0]
        self.assertAlmostEqual(sent, 32.5197, places=4)
        self.assertEqual(self.log.rows[-1]['u_raw'], self.log.rows[-1]['u_sent'])

    def test_binary_frame(self):
        self.assertEqual(app.pack_u(10).hex(' '), 'aa 55 00 00 20 41 60 0d')
        self.assertEqual(app.pack_u(-10).hex(' '), 'aa 55 00 00 20 c1 e0 0d')

    def test_fragmentation_and_echo_filter(self):
        p = app.StateLines()
        self.assertEqual(p.feed(b'666<32>:1,0.01,0.02,'), [])
        states = p.feed(b'0.03,0.04\n<back>:1.000\nRX ERROR\n')
        self.assertEqual(states, [(1, (0.01,0.02,0.03,0.04))])
        self.assertEqual(p.rx_errors, 1)
        self.assertEqual(p.bad, 0)

    def test_invalid_and_overlong_lines_recover(self):
        p = app.StateLines()
        self.assertEqual(p.feed(b'<32>:1,nan,0,0,0\n'), [])
        self.assertEqual(p.feed(b'x'*3000+b'\n'), [])
        self.assertEqual(p.feed(b'<32>:2,0,0,0,0\n'), [(2,(0,0,0,0))])
        self.assertEqual(p.bad, 2)

    def test_latest_state_only_but_all_states_recorded(self):
        self.worker.enabled = True
        states = [(1,(1,0,0,0)), (2,(0.01,0,0,0))]
        self.worker.on_states(self.port, states, time.monotonic())
        self.assertEqual(len(self.port.writes), 1)
        u = struct.unpack('<f',self.port.writes[0][2:6])[0]
        self.assertAlmostEqual(u, 0.325197, places=6)
        self.assertEqual([r['cnt'] for r in self.log.rows], [1,2])
        self.assertEqual(self.log.rows[0]['mode'], 'skipped_backlog')

    def test_monitor_does_not_send(self):
        self.worker.on_states(self.port, [(1,(0,0,0,0))], time.monotonic())
        self.assertEqual(self.port.writes, [])
        self.assertEqual(self.log.rows[-1]['u_sent'], '')

    def test_stop_request_sends_zero_and_closes(self):
        self.worker.start()
        try:
            wait_for(lambda: self.worker.connected)
            self.worker.stop_control()
            wait_for(lambda: len(self.port.writes) > 0)
            self.assertEqual(self.port.writes[0], app.pack_u(0))
        finally:
            self.worker.end.set()
            self.worker.join(1)
        self.assertTrue(self.port.closed)
        self.assertFalse(self.worker.is_alive())

    def test_state_timeout_disables_and_sends_zero(self):
        self.worker.start()
        try:
            self.port.incoming.put(b'<32>:1,0,0,0,0\n')
            wait_for(lambda: self.worker.received == 1)
            self.assertTrue(self.worker.enable())
            self.port.incoming.put(b'<32>:2,0.01,0,0,0\n')
            wait_for(lambda: len(self.port.writes) >= 2)
            self.assertFalse(self.worker.enabled)
            self.assertEqual(self.port.writes[-1], app.pack_u(0))
            self.assertTrue(any(r['mode'] == 'state_timeout' for r in self.log.rows))
        finally:
            self.worker.end.set()
            self.worker.join(1)

    def test_real_csv_records_state_and_zero_events(self):
        # tempfile manages only its own newly-created directory under this folder.
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            recorder = app.Recorder(directory)
            recorder.start()
            recorder.add(dict(t_s=0.1, cnt=1, x_m=0.01, v_m_s=0.02,
                              theta_rad=0.03, omega_rad_s=0.04, u_raw=1, u_sent=1, mode='lqr'))
            recorder.add(dict(t_s=0.2, u_sent=0, mode='stop'))
            recorder.done.set()
            recorder.join(1)
            self.assertFalse(recorder.is_alive())
            with recorder.path.open(encoding='utf-8-sig', newline='') as f:
                rows = list(csv.DictReader(f))
            self.assertEqual(len(rows), 2)
            self.assertEqual(rows[0]['theta_rad'], '0.03')
            self.assertEqual(rows[1]['mode'], 'stop')

    def test_hidden_gui_draws_five_curves(self):
        try:
            import tkinter as tk
            root = tk.Tk()
            root.withdraw()
        except Exception as exc:
            self.skipTest('GUI display unavailable: '+str(exc))
        try:
            window = app.PlotWindow(root, self.worker, self.log, demo=True)
            root.update_idletasks()
            samples = [(i/50, (i/1000, i/2000, i/3000, i/4000), i/100) for i in range(50)]
            window.draw(samples, 1.0)
            curve_colors = set(app.PlotWindow.COLORS)
            curves = [item for item in window.canvas.find_all()
                      if window.canvas.type(item) == 'line' and
                      window.canvas.itemcget(item, 'fill') in curve_colors]
            self.assertEqual(len(curves), 5)
            for item in curves:
                self.assertTrue(all(math.isfinite(float(v)) for v in window.canvas.coords(item)))
            window.closed = True
            root.after_cancel(window.after_id)
        finally:
            root.destroy()

    def test_demo_gui_control_record_and_close(self):
        try:
            import tkinter as tk
            root = tk.Tk()
            root.withdraw()
        except Exception as exc:
            self.skipTest('GUI display unavailable: '+str(exc))
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            recorder = app.Recorder(directory)
            worker = app.Controller(app.DemoSerial, recorder)
            recorder.start()
            worker.start()
            window = app.PlotWindow(root, worker, recorder, demo=True)
            root.after(100, worker.enable)
            root.after(550, window.close)
            root.mainloop()
            self.assertFalse(worker.is_alive())
            self.assertFalse(recorder.is_alive())
            with recorder.path.open(encoding='utf-8-sig', newline='') as f:
                rows = list(csv.DictReader(f))
            controlled = [r for r in rows if r['mode'] == 'lqr']
            self.assertGreater(len(controlled), 5)
            self.assertTrue(all(r['rx_to_write_ms'] for r in controlled))
            self.assertEqual(rows[-1]['mode'], 'exit')
            self.assertEqual(float(rows[-1]['u_sent']), 0)


if __name__ == '__main__':
    unittest.main()
