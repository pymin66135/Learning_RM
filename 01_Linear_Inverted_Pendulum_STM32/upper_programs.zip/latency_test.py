#!/usr/bin/env python3
"""Measure host state receipt -> command -> STM32 <back> reply. Python 3.9."""
import argparse
import csv
import json
import math
import statistics
import struct
import time
from datetime import datetime
from pathlib import Path

K = (-21.5565, -33.1765, -67.756, -12.6289)
FIELDS = ("sample", "cnt", "x", "v", "theta", "omega", "u",
          "state_to_send_ms", "send_to_back_ms", "state_to_back_ms",
          "back_u", "ok", "reason")


def pack_u(u):
    if not math.isfinite(u):
        raise ValueError("u must be finite")
    body = b"\xAA\x55" + struct.pack("<f", u)
    return body + bytes((sum(body) & 255, 13))


def parse_line(data):
    text = data.decode("ascii", errors="replace").strip()
    if text.startswith("666"):
        text = text[3:]
    try:
        if text.startswith("<32>:"):
            parts = text[5:].split(",")
            if len(parts) != 5:
                return None
            state = tuple(float(s) for s in parts[1:])
            if all(math.isfinite(s) for s in state):
                return ("state", int(parts[0]), state)
        elif text.startswith("<back>:"):
            value = float(text[7:])
            if math.isfinite(value):
                return ("back", value)
        elif text == "RX ERROR":
            return ("error",)
    except ValueError:
        pass
    return None


def distribution(values):
    if not values:
        return None
    a = sorted(values)
    def quantile(p):
        pos = (len(a)-1)*p
        lo = int(pos)
        return a[lo] + (a[min(lo+1, len(a)-1)]-a[lo])*(pos-lo)
    return dict(n=len(a), mean=statistics.mean(a), median=quantile(.5),
                p95=quantile(.95), p99=quantile(.99), min=a[0], max=a[-1])


def measure(port, args, writer):
    rows = []
    pending = None
    partial = bytearray()
    skipped = stray = 0
    status = "FAIL"
    started = last_state = time.perf_counter_ns()

    def finish(reply=None, ok=False, reason="timeout", now=None):
        nonlocal pending
        now = time.perf_counter_ns() if now is None else now
        r = dict(sample=pending["sample"], cnt=pending["cnt"],
                 x=pending["state"][0], v=pending["state"][1],
                 theta=pending["state"][2], omega=pending["state"][3],
                 u=pending["u"],
                 state_to_send_ms=(pending["tx_done"]-pending["rx"])/1e6,
                 send_to_back_ms=(now-pending["tx"])/1e6 if reply is not None else "",
                 state_to_back_ms=(now-pending["rx"])/1e6 if reply is not None else "",
                 back_u="" if reply is None else reply, ok=int(ok), reason=reason)
        writer.writerow(r)  # After the echo timestamp, outside the measured interval.
        rows.append(r)
        if len(rows) % 50 == 0 or not ok or len(rows) == args.count:
            print("{}/{}: state->back={} ms, send->back={} ms, {}".format(
                len(rows), args.count,
                "-" if r["state_to_back_ms"] == "" else "{:.3f}".format(r["state_to_back_ms"]),
                "-" if r["send_to_back_ms"] == "" else "{:.3f}".format(r["send_to_back_ms"]),
                "OK" if ok else reason), flush=True)
        pending = None

    try:
        while len(rows) < args.count:
            chunk = port.read_until(b"\n", size=1024)
            now = time.perf_counter_ns()
            if pending is not None and (now-pending["tx"])/1e9 > args.timeout:
                finish(reason="timeout", now=now)
                break
            partial.extend(chunk)
            if len(partial) > 2048:
                partial.clear()
            if partial.endswith(b"\n"):
                event = parse_line(bytes(partial))
                partial.clear()
                if event and event[0] == "state":
                    last_state = now
                    if pending is not None:
                        skipped += 1
                    else:
                        cnt, state = event[1:]
                        u = -sum(k*s for k,s in zip(K,state)) if args.lqr else args.u
                        packet = pack_u(u)
                        wire_u = struct.unpack("<f", packet[2:6])[0]
                        tx = time.perf_counter_ns()
                        if port.write(packet) != 8:
                            raise OSError("incomplete serial write")
                        pending = dict(sample=len(rows)+1, cnt=cnt, state=state,
                                       u=wire_u, rx=now, tx=tx,
                                       tx_done=time.perf_counter_ns())
                elif event and event[0] == "back":
                    if pending is None:
                        stray += 1
                    else:
                        good = abs(event[1]-pending["u"]) <= 0.00051
                        finish(event[1], good, "OK" if good else "value mismatch", now)
                        if not good:
                            break
                elif event and event[0] == "error" and pending is not None:
                    finish(reason="RX ERROR", now=now)
                    break
            now = time.perf_counter_ns()
            if pending is not None and (now-pending["tx"])/1e9 > args.timeout:
                finish(reason="timeout", now=now)
                break  # Do not misassign a late echo to the next command.
            if pending is None and (now-last_state)/1e9 > 5:
                print("No valid state frame for 5 seconds.", flush=True)
                break
        if len(rows) == args.count and all(r["ok"] for r in rows):
            status = "PASS"
    except KeyboardInterrupt:
        status = "INTERRUPTED"
    except Exception as exc:
        status = "ERROR"
        print("Error: {}".format(exc), flush=True)
    finally:
        # No extra handshake. This single exit command is excluded from statistics.
        try:
            port.write(pack_u(0.0))
            print("Exit: submitted u=0.", flush=True)
        except Exception:
            print("Exit zero command not confirmed; use the stop switch.", flush=True)
    good_rows = [r for r in rows if r["ok"]]
    return dict(status=status, requested=args.count, sent=len(rows)+(pending is not None),
                matched=len(good_rows), completed=len(rows),
                return_rate=len(good_rows)/(len(rows)+(pending is not None)) if rows or pending else 0,
                timeout_count=sum(r["reason"] == "timeout" for r in rows),
                error_count=sum(r["reason"] == "RX ERROR" for r in rows),
                mismatch_count=sum(r["reason"] == "value mismatch" for r in rows),
                skipped_states=skipped, stray_back=stray,
                duration_s=(time.perf_counter_ns()-started)/1e9,
                state_to_send_ms=distribution([r["state_to_send_ms"] for r in good_rows]),
                send_to_back_ms=distribution([r["send_to_back_ms"] for r in good_rows]),
                state_to_back_ms=distribution([r["state_to_back_ms"] for r in good_rows]),
                note="Host timestamps. No command ID; pairing uses one outstanding request and echoed value.")


def main():
    p = argparse.ArgumentParser(description="state receipt -> u -> <back> latency, no firmware changes")
    p.add_argument("--port", default="/dev/ttyUSB0")
    p.add_argument("--baud", type=int, default=2000000)
    p.add_argument("--count", type=int, default=500)
    p.add_argument("--u", type=float, default=0.0, help="constant command, default 0, no amplitude clipping")
    p.add_argument("--lqr", action="store_true", help="compute u=-K*state instead of constant u")
    p.add_argument("--timeout", type=float, default=0.2)
    a = p.parse_args()
    if a.baud <= 0 or a.count <= 0 or not math.isfinite(a.u) or not math.isfinite(a.timeout) or a.timeout <= 0:
        p.error("count and timeout must be positive; u must be finite")
    import serial
    folder = Path(__file__).resolve().parent / "latency_logs"
    folder.mkdir(parents=True, exist_ok=True)
    stem = folder / ("latency_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
    port = serial.Serial(port=None, baudrate=a.baud, timeout=.005,
                         write_timeout=.1, exclusive=True)
    port.dtr = False
    port.rts = False
    port.port = a.port
    with port:
        time.sleep(2.2)
        port.reset_input_buffer()
        print("Port: {}; baud: {}".format(a.port, a.baud), flush=True)
        print("Mode: {}; count={}; waiting for <32> states.".format(
            "LQR (unclipped)" if a.lqr else "constant u={}".format(a.u), a.count), flush=True)
        with stem.with_suffix(".csv").open("x", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            writer.writeheader()
            result = measure(port, a, writer)
    result.update(mode="lqr" if a.lqr else "constant", constant_u=None if a.lqr else a.u, port=a.port, baudrate=a.baud)
    stem.with_suffix(".json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print("\n{}: matched {}/{} ({:.2f}%), timeout={}, RX ERROR={}, mismatch={}".format(
        result["status"], result["matched"], result["sent"], result["return_rate"]*100,
        result["timeout_count"], result["error_count"], result["mismatch_count"]))
    for key in ("state_to_send_ms", "send_to_back_ms", "state_to_back_ms"):
        s = result[key]
        if s:
            print("{}: mean={:.3f}, P95={:.3f}, P99={:.3f}, max={:.3f} ms".format(
                key,s["mean"],s["p95"],s["p99"],s["max"]))
    print("CSV: {}".format(stem.with_suffix(".csv")))
    print("JSON: {}".format(stem.with_suffix(".json")))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
