#!/usr/bin/env python3
"""Serial timing probe: host receipt times, distinct u values, no STM32 changes."""
import argparse
import csv
import json
import math
import struct
import time
from datetime import datetime
from pathlib import Path
from latency_test import pack_u, parse_line, distribution


def main():
    parser = argparse.ArgumentParser(description="Measure state intervals and distinct-u echoes")
    parser.add_argument("--port", default="/dev/ttyUSB0")
    parser.add_argument("--baud", type=int, default=2000000)
    parser.add_argument("--count", type=int, default=500)
    parser.add_argument("--raw-seconds", type=float, default=3.0)
    parser.add_argument("--u-start", type=float, default=0.001)
    parser.add_argument("--u-step", type=float, default=0.001)
    parser.add_argument("--timeout", type=float, default=0.2)
    args = parser.parse_args()
    if args.count <= 0 or args.baud <= 0 or not math.isfinite(args.timeout) or args.timeout <= 0:
        parser.error("count, baud and timeout must be positive")
    if not math.isfinite(args.raw_seconds) or args.raw_seconds < 0:
        parser.error("raw-seconds must be nonnegative")
    # Echo precision is 0.001: distinguish every command at that precision.
    try:
        commands = [struct.unpack("<f", pack_u(args.u_start+i*args.u_step)[2:6])[0]
                    for i in range(args.count)]
    except (ValueError, OverflowError):
        parser.error("u values must fit finite float32")
    labels = ["{:.3f}".format(u) for u in commands]
    if len(set(labels)) != args.count or any(label in ("0.000", "-0.000") for label in labels):
        parser.error("each u must be nonzero and distinct at 3 decimals; increase u-step")

    import serial
    folder = Path(__file__).resolve().parent / "timing_logs"
    folder.mkdir(exist_ok=True)
    stem = folder / ("timing_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
    port = serial.Serial(port=None, baudrate=args.baud, timeout=.005,
                         write_timeout=.1, exclusive=True)
    port.dtr = False
    port.rts = False
    port.port = args.port
    events, rows = [], []
    intervals = {"passive": [], "active": []}
    state_counts = {"passive": 0, "active": 0}
    gaps = repeats = stray = errors = mismatch = timeouts = skipped = 0
    partial = bytearray()
    pending = previous_state = latest_pair = None
    status = "FAIL"
    origin = time.perf_counter_ns()

    def read_event(phase):
        chunk = port.read_until(b"\n", size=1024)
        now = time.perf_counter_ns()
        partial.extend(chunk)
        if not partial.endswith(b"\n"):
            return None
        raw = bytes(partial)
        partial.clear()
        parsed = parse_line(raw)
        record = dict(phase=phase, host_ns=now-origin, kind=parsed[0] if parsed else "other",
                      text=raw.decode("ascii", "replace").rstrip("\r\n"), hex=raw.hex(" "))
        events.append(record)
        return now, parsed, record

    def record_state(now, event, phase):
        nonlocal previous_state, gaps, repeats
        state_counts[phase] += 1
        if previous_state is not None and previous_state[2] == phase:
            dt = (now-previous_state[0])/1e6
            intervals[phase].append(dt)
            events[-1]["state_interval_ms"] = dt
            jump = event[1]-previous_state[1]
            if jump > 1:
                gaps += jump-1
            elif jump <= 0:
                repeats += 1
        previous_state = (now, event[1], phase)

    try:
        port.open()
    except serial.SerialException as exc:
        print("Cannot open serial port: {}".format(exc))
        print("Close the LQR GUI / other serial programs, then rerun this probe.")
        return 2

    with port:
        time.sleep(2.2)
        port.reset_input_buffer()
        origin = time.perf_counter_ns()
        print("Port: {}; baud: {}".format(args.port, args.baud), flush=True)
        deadline = time.perf_counter()+args.raw_seconds
        while time.perf_counter() < deadline:
            item = read_event("passive")
            if item is None:
                continue
            now, event, record = item
            if event and event[0] == "state":
                record_state(now, event, "passive")
            if len(events) <= 8:
                print("RAW {:9.3f} ms  {}".format(record["host_ns"]/1e6, repr(record["text"])), flush=True)

        previous_state = None
        last_state = time.perf_counter_ns()
        print("Sending {} distinct u: {} ... {} (no amplitude clipping)".format(
            args.count, labels[0], labels[-1]), flush=True)
        try:
            while True:
                item = read_event("active")
                now = time.perf_counter_ns() if item is None else item[0]
                if pending is not None and (now-pending["tx_ns"])/1e9 > args.timeout:
                    timeouts += 1
                    pending["reason"] = "timeout"
                    rows.append(pending)
                    pending = None
                    break
                if item is not None:
                    now, event, record = item
                    if event and event[0] == "state":
                        record_state(now, event, "active")
                        last_state = now
                        if latest_pair is not None:
                            latest_pair["next_state_cnt"] = event[1]
                            latest_pair["state_to_next_state_ms"] = (now-latest_pair["state_ns"])/1e6
                            latest_pair["back_to_next_state_ms"] = (now-latest_pair["back_ns"])/1e6
                            latest_pair = None
                        if len(rows) >= args.count:
                            status = "PASS" if all(r["ok"] for r in rows) else "FAIL"
                            break
                        if pending is not None:
                            skipped += 1
                            continue
                        index = len(rows)
                        packet = pack_u(commands[index])
                        tx = time.perf_counter_ns()
                        written = port.write(packet)
                        done = time.perf_counter_ns()
                        pending = dict(sample=index+1, state_cnt=event[1], u=commands[index],
                                       expected=labels[index], state_ns=now, tx_ns=tx,
                                       state_to_send_ms=(tx-now)/1e6, write_ms=(done-tx)/1e6,
                                       x=event[2][0], v=event[2][1], theta=event[2][2],
                                       omega=event[2][3], ok=False, reason="waiting")
                        if written != 8:
                            raise OSError("Incomplete serial write")
                    elif event and event[0] == "back":
                        if pending is None:
                            stray += 1
                            continue
                        good = "{:.3f}".format(event[1]) == pending["expected"]
                        pending.update(back_u=event[1], back_ns=now, ok=good,
                                       reason="OK" if good else "mismatch",
                                       send_to_back_ms=(now-pending["tx_ns"])/1e6,
                                       state_to_back_ms=(now-pending["state_ns"])/1e6)
                        rows.append(pending)
                        latest_pair = pending
                        pending = None
                        if not good:
                            mismatch += 1
                            break
                        if len(rows) <= 5 or len(rows) % 50 == 0:
                            print("{}/{} u={:.3f}, back={:.3f}, state->back={:.3f} ms".format(
                                len(rows), args.count, rows[-1]["u"], event[1],
                                rows[-1]["state_to_back_ms"]), flush=True)
                    elif event and event[0] == "error":
                        errors += 1
                        if pending:
                            pending["reason"] = "RX ERROR"
                            rows.append(pending)
                            pending = None
                        break
                if (now-last_state)/1e9 > 5:
                    print("No state for 5 seconds.", flush=True)
                    break
        except KeyboardInterrupt:
            status = "INTERRUPTED"
        except Exception as exc:
            status = "ERROR"
            print("Error: {}".format(exc), flush=True)
        finally:
            if pending is not None:
                pending["reason"] = status
                rows.append(pending)
            try:
                port.write(pack_u(0))
                print("Exit: submitted u=0.", flush=True)
            except Exception as exc:
                print("Exit write failed: {}".format(exc), flush=True)

    # Full-line receipt interval between consecutive <back> echoes.
    previous_back_ns = None
    back_intervals = []
    for row in rows:
        if "back_ns" in row:
            if previous_back_ns is not None:
                row["back_interval_ms"] = (row["back_ns"]-previous_back_ns)/1e6
                back_intervals.append(row["back_interval_ms"])
            previous_back_ns = row["back_ns"]
    good = [r for r in rows if r["ok"]]
    result = dict(status=status, port=args.port, baud=args.baud, requested=args.count,
                  sent=len(rows), matched=len(good), timeouts=timeouts, mismatch=mismatch,
                  rx_errors=errors, stray_echoes=stray, skipped_states=skipped,
                  state_counts=state_counts, cnt_gaps=gaps, cnt_nonincreasing=repeats,
                  u_start=args.u_start, u_step=args.u_step,
                  back_to_back_ms=distribution(back_intervals),
                  passive_state_interval_ms=distribution(intervals["passive"]),
                  active_state_interval_ms=distribution(intervals["active"]),
                  note="Host full-line receipt timestamps; USB/OS buffering included. No STM32 sampling timestamps.")
    for key in ("state_to_send_ms", "write_ms", "send_to_back_ms", "state_to_back_ms",
                "state_to_next_state_ms", "back_to_next_state_ms"):
        result[key] = distribution([r[key] for r in good if key in r])
    stem.with_suffix(".json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    stem.with_suffix(".raw.json").write_text(json.dumps(events, indent=2), encoding="utf-8")
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with stem.with_suffix(".csv").open("w", newline="", encoding="utf-8-sig") as f:
        if fields:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)
    print("\n{}: matched {}/{}, timeout={}, mismatch={}, RX ERROR={}, cnt gaps={}".format(
        status, len(good), len(rows), timeouts, mismatch, errors, gaps))
    for key, value in result.items():
        if isinstance(value, dict) and "mean" in value:
            print("{}: mean={:.3f}, P95={:.3f}, P99={:.3f}, min={:.3f}, max={:.3f} ms".format(
                key, value["mean"], value["p95"], value["p99"], value["min"], value["max"]))
    print("Logs: {}[.json / .raw.json / .csv]".format(stem))
    return 0 if status == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
